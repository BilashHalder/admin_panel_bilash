import '../styles/globals.css'
import '../public/assets/css/demo_1/style.css'
function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp
