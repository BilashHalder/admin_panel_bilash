import React, { useState } from 'react'
import Clock from 'react-live-clock';
import Link from 'next/link';
export default function SideBar(props) {

  return (
    
    <nav className="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item nav-profile border-bottom">
          <div class="nav-profile-image">
            <img src="../assets/images/faces/face1.jpg" alt="profile" />
          </div>
          <div class="nav-profile-text d-flex ml-0 mb-3 flex-column">
            <span class="font-weight-semibold mb-1 mt-2 text-center mb-1">Admin Name</span>
            <span class="text-secondary icon-sm text-center"> {new Date().toDateString()}</span>
            
          </div>
      </li>
      <li class="nav-item pt-3">
        <div class="nav-link d-block">
          <img class="sidebar-brand-logo" src="../assets/images/logo.png" alt="" />
          <img class="sidebar-brand-logomini" src="../assets/images/logo-mini.svg" alt="" />
        </div>
      </li>
      <li class="pt-2 pb-1">
       
      </li>
      <li class="nav-item">
        <Link href="/">
        <a class="nav-link" >
          <i class="mdi mdi-view-dashboard menu-icon"></i>
          <span class="menu-title">Dashboard</span>
        </a>
        </Link>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#customer" aria-expanded="false" aria-controls="customer">
          <i class="fa fa-users menu-icon"></i>
          <span class="menu-title">Manage Customer</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="customer">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item mb-1">
             <Link href="/admin" class="nav-link" > Add New Customer </Link> 
            </li>
            <li class="nav-item mb-1">
              <Link class="nav-link" href="/admin">All Customer </Link>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#employee" aria-expanded="false" aria-controls="employee">
          <i class="mdi mdi-account menu-icon"></i>
          <span class="menu-title">Manage Employee</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="employee">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item mb-1">
             <Link href="/" class="nav-link" > All Employee </Link> 
            </li>
            <li class="nav-item mb-1">
              <Link class="nav-link" href="/">Add Employee</Link>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#associate" aria-expanded="false" aria-controls="associate">
          <i class="fa fa-handshake-o menu-icon"></i>
          <span class="menu-title">Manage Associate</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="associate">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item mb-1">
             <Link href="/" class="nav-link" >Add Associate  </Link> 
            </li>
            <li class="nav-item mb-1">
              <Link class="nav-link" href="/">All Associate </Link>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#transaction" aria-expanded="false" aria-controls="transaction">
          <i class="fa fa-money menu-icon"></i>
          <span class="menu-title">Transaction</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="transaction">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item mb-1">
             <Link href="/" class="nav-link" >Transaction Request </Link> 
            </li>
            <li class="nav-item mb-1">
              <Link class="nav-link" href="/">Verification</Link>
            </li>
            <li class="nav-item mb-1">
              <Link class="nav-link" href="/">Pending Transaction</Link>
            </li>
            <li class="nav-item mb-1">
              <Link class="nav-link" href="/">Failed Transaction</Link>
            </li>
            
            <li class="nav-item mb-1">
              <Link class="nav-link" href="/">All Transaction</Link>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#others" aria-expanded="false" aria-controls="others">
          <i class="mdi mdi-buffer menu-icon"></i>
          <span class="menu-title">Others</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="others">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item mb-1">
             <Link href="/" class="nav-link" > Salary </Link> 
            </li>
            <li class="nav-item mb-1">
              <Link class="nav-link" href="/">Designation</Link>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <Link href="/">
        <a class="nav-link" >
          <i class="fa fa-sign-out menu-icon"></i>
          <span class="menu-title">Log Out</span>
        </a>
        </Link>
      </li>

    </ul>
  </nav>
  )
}
